$ErrorActionPreference = "Stop"
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$appSource = Get-ChildItem -Path $base -Recurse -Filter index.html | Select-Object -First 1
if (-not $appSource) { throw "لم يتم العثور على ملفات البرنامج." }
$appRoot = $appSource.Directory.FullName
$dest = Join-Path $env:LOCALAPPDATA "LegendsSMS"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Path (Join-Path $appRoot "*") -Destination $dest -Recurse -Force
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcut = Join-Path $desktop "LEGENDS SMS.lnk"
$ws = New-Object -ComObject WScript.Shell
$sc = $ws.CreateShortcut($shortcut)
$sc.TargetPath = Join-Path $dest "LEGENDS_SMS.bat"
$sc.WorkingDirectory = $dest
$sc.Description = "Legends School & Kindergarten - School Management System"
$sc.IconLocation = "$env:SystemRoot\System32\SHELL32.dll,21"
$sc.Save()
Start-Process (Join-Path $dest "LEGENDS_SMS.bat")
Write-Host "تم تثبيت LEGENDS SMS وإنشاء الاختصار على سطح المكتب."
Pause
