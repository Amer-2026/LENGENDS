@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install_LEGENDS_SMS.ps1"
